#!/bin/bash

# Module: Enterprise Network Health Check
# Author: TuxFix Team
# Description: Comprehensive network diagnostics including connectivity, DNS, routing, latency, packet loss, and security
# Version: 2.0

run_network() {
    print_info "Starting enterprise network diagnostics..."
    
    # Check for required tools
    check_network_tools
    
    # Core network checks
    check_network_interfaces
    check_default_gateway
    check_dns_configuration
    check_dns_resolution
    check_internet_connectivity
    check_latency_and_packet_loss
    check_bandwidth_utilization
    check_tcp_ports
    check_firewall_rules
    check_routing_table
    check_mtu_issues
    check_arp_table
    check_network_services
    check_bonding_teaming
    check_vlan_configuration
    check_ipv6_configuration
    check_network_security
    
    return 0
}

# Check for required network tools
check_network_tools() {
    print_info "Checking network diagnostic tools..."
    
    local required_tools=("ping" "ip" "ss" "netstat" "arp" "ethtool" "nslookup" "dig" "traceroute" "mtr" "curl")
    local missing_tools=()
    
    for tool in "${required_tools[@]}"; do
        if ! command_exists "$tool"; then
            missing_tools+=("$tool")
        fi
    done
    
    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        print_warning "Missing network tools: ${missing_tools[*]}"
        add_issue "network_missing_tools" \
            "Missing network diagnostic tools: ${missing_tools[*]}" \
            "Install: apt install iputils-ping dnsutils traceroute mtr curl ethtool (Debian/Ubuntu) OR dnf install iputils bind-utils traceroute mtr curl ethtool (RHEL/Fedora)" \
            "warning"
    else
        print_success "All network tools available"
    fi
}

# Check network interfaces
check_network_interfaces() {
    print_info "Checking network interfaces..."
    
    local interfaces=$(ip link show | grep -E '^[0-9]+:' | grep -v lo | awk -F': ' '{print $2}')
    
    if [[ -z "$interfaces" ]]; then
        add_issue "network_no_interfaces" \
            "No network interfaces found (excluding loopback)" \
            "Check network hardware: lspci | grep -i ethernet; dmesg | grep -i eth" \
            "critical"
        return 1
    fi
    
    for iface in $interfaces; do
        # Check if interface is up
        local iface_state=$(ip link show "$iface" | grep -oP '(?<=state )\w+' 2>/dev/null)
        
        if [[ "$iface_state" != "UP" ]]; then
            print_warning "Interface $iface is down (state: $iface_state)"
            add_issue "network_interface_down_$iface" \
                "Network interface $iface is down" \
                "sudo ip link set $iface up; Check cable connection if physical" \
                "critical"
            continue
        fi
        
        # Get IP address
        local ipv4=$(ip -4 addr show "$iface" 2>/dev/null | grep -oP '(?<=inet\s)\d+(\.\d+){3}/\d+' | head -1)
        local ipv6=$(ip -6 addr show "$iface" 2>/dev/null | grep -oP '(?<=inet6\s)[a-f0-9:]+/\d+' | grep -v '^fe80' | head -1)
        
        if [[ -z "$ipv4" ]]; then
            print_warning "Interface $iface has no IPv4 address"
            add_issue "network_no_ipv4_$iface" \
                "Interface $iface is up but has no IPv4 address" \
                "Check DHCP: sudo dhclient $iface; Or configure static IP" \
                "warning"
        else
            print_success "Interface $iface: $ipv4"
        fi
        
        if [[ -n "$ipv6" ]]; then
            print_info "Interface $iface IPv6: $ipv6"
        fi
        
        # Check for errors/dropped packets
        local rx_errors=$(ip -s link show "$iface" 2>/dev/null | grep -A1 RX: | tail -1 | awk '{print $2}')
        local tx_errors=$(ip -s link show "$iface" 2>/dev/null | grep -A1 TX: | tail -1 | awk '{print $2}')
        local rx_dropped=$(ip -s link show "$iface" 2>/dev/null | grep -A1 RX: | tail -1 | awk '{print $3}')
        local tx_dropped=$(ip -s link show "$iface" 2>/dev/null | grep -A1 TX: | tail -1 | awk '{print $3}')
        
        if [[ "$rx_errors" -gt 0 ]] || [[ "$tx_errors" -gt 0 ]]; then
            print_warning "Interface $iface has errors: RX=$rx_errors TX=$tx_errors"
            add_issue "network_interface_errors_$iface" \
                "Interface $iface has $rx_errors RX errors and $tx_errors TX errors" \
                "Check cable, switch port, or NIC health; Replace cable or NIC if needed" \
                "warning"
        fi
        
        if [[ "$rx_dropped" -gt 100 ]] || [[ "$tx_dropped" -gt 100 ]]; then
            print_warning "Interface $iface has dropped packets: RX=$rx_dropped TX=$tx_dropped"
            add_issue "network_interface_drops_$iface" \
                "Interface $iface has excessive dropped packets" \
                "Check for buffer overruns: ethtool -S $iface; Increase ring buffer size" \
                "warning"
        fi
        
        # Check link speed with ethtool
        if command_exists ethtool; then
            local speed=$(ethtool "$iface" 2>/dev/null | grep -i "Speed:" | awk '{print $2}')
            local duplex=$(ethtool "$iface" 2>/dev/null | grep -i "Duplex:" | awk '{print $2}')
            
            if [[ -n "$speed" ]]; then
                print_info "$iface speed: $speed, duplex: $duplex"
                
                # Check for unexpected speed (10Mbit on gigabit network)
                if [[ "$speed" == "10Mb/s" ]] || [[ "$speed" == "100Mb/s" ]]; then
                    add_issue "network_slow_speed_$iface" \
                        "Interface $iface running at slow speed: $speed" \
                        "Check cable quality, switch port autonegotiation, or force higher speed" \
                        "warning"
                fi
            fi
        fi
    done
}

# Check default gateway
check_default_gateway() {
    print_info "Checking default gateway..."
    
    local gateway=$(ip route show default 2>/dev/null | awk '/default/ {print $3}' | head -1)
    local interface=$(ip route show default 2>/dev/null | awk '/default/ {print $5}' | head -1)
    
    if [[ -z "$gateway" ]]; then
        add_issue "network_no_gateway" \
            "No default gateway configured" \
            "Add gateway: sudo ip route add default via <gateway_ip> dev <interface>; Or configure DHCP" \
            "critical"
        return 1
    fi
    
    print_success "Default gateway: $gateway via $interface"
    
    # Check if gateway is reachable
    if ping -c2 -W2 "$gateway" &>/dev/null; then
        print_success "Gateway $gateway is reachable"
        
        # Measure gateway latency
        local gateway_latency=$(ping -c3 "$gateway" 2>/dev/null | awk -F'/' '/rtt/ {print $5}')
        if [[ -n "$gateway_latency" ]]; then
            print_info "Gateway latency: ${gateway_latency}ms"
            
            if (( $(echo "$gateway_latency > 10" | bc -l 2>/dev/null || echo "0") )); then
                add_issue "network_high_gateway_latency" \
                    "High gateway latency: ${gateway_latency}ms" \
                    "Check local network congestion, WiFi interference, or switch issues" \
                    "warning"
            fi
        fi
    else
        add_issue "network_gateway_unreachable" \
            "Default gateway $gateway is not reachable" \
            "Check network connection, switch, or router; Verify gateway IP is correct" \
            "critical"
    fi
}

# Check DNS configuration
check_dns_configuration() {
    print_info "Checking DNS configuration..."
    
    local resolv_conf="/etc/resolv.conf"
    local dns_servers=()
    
    if [[ -f "$resolv_conf" ]]; then
        mapfile -t dns_servers < <(grep -E '^nameserver' "$resolv_conf" | awk '{print $2}')
        
        if [[ ${#dns_servers[@]} -eq 0 ]]; then
            add_issue "network_no_dns_servers" \
                "No DNS servers configured in $resolv_conf" \
                "Add nameservers: echo 'nameserver 8.8.8.8' >> /etc/resolv.conf; echo 'nameserver 1.1.1.1' >> /etc/resolv.conf" \
                "critical"
        else
            print_success "DNS servers configured: ${dns_servers[*]}"
            
            # Check for localhost DNS (usually not desirable)
            for dns in "${dns_servers[@]}"; do
                if [[ "$dns" == "127.0.0.1" ]] || [[ "$dns" == "::1" ]]; then
                    print_warning "DNS server points to localhost - may cause resolution issues"
                    add_issue "network_dns_localhost" \
                        "DNS server configured as localhost ($dns)" \
                        "Check if local DNS resolver (dnsmasq, systemd-resolved) is running; Verify configuration" \
                        "warning"
                fi
            done
        fi
    else
        add_issue "network_no_resolv_conf" \
            "DNS configuration file $resolv_conf not found" \
            "Create: echo 'nameserver 8.8.8.8' > /etc/resolv.conf; echo 'nameserver 1.1.1.1' >> /etc/resolv.conf" \
            "critical"
    fi
    
    # Check systemd-resolved if active
    if command_exists systemctl && systemctl is-active --quiet systemd-resolved 2>/dev/null; then
        print_info "systemd-resolved is active"
        
        if [[ ! -L "$resolv_conf" ]] || [[ ! -f "/run/systemd/resolve/stub-resolv.conf" ]]; then
            print_warning "systemd-resolved active but /etc/resolv.conf not properly linked"
            add_issue "network_systemd_resolved_config" \
                "systemd-resolved is active but /etc/resolv.conf is not a symlink to stub-resolv.conf" \
                "sudo ln -sf /run/systemd/resolve/stub-resolv.conf /etc/resolv.conf" \
                "warning"
        fi
    fi
}

# Check DNS resolution
check_dns_resolution() {
    print_info "Testing DNS resolution..."
    
    local test_domains=("google.com" "github.com" "cloudflare.com")
    local resolved_failures=0
    
    for domain in "${test_domains[@]}"; do
        local resolved_ip=""
        
        if command_exists dig; then
            resolved_ip=$(dig +short "$domain" 2>/dev/null | grep -E '^[0-9.]+$' | head -1)
        elif command_exists nslookup; then
            resolved_ip=$(nslookup "$domain" 2>/dev/null | grep -A1 'Name:' | grep 'Address:' | awk '{print $2}' | head -1)
        elif command_exists host; then
            resolved_ip=$(host "$domain" 2>/dev/null | grep 'has address' | awk '{print $4}' | head -1)
        else
            resolved_ip=$(ping -c1 "$domain" 2>/dev/null | grep -oP '(?<=\(\))[0-9.]+' | head -1)
        fi
        
        if [[ -n "$resolved_ip" ]]; then
            print_success "DNS resolution: $domain -> $resolved_ip"
        else
            print_warning "Failed to resolve $domain"
            ((resolved_failures++))
        fi
    done
    
    if [[ $resolved_failures -gt 1 ]]; then
        add_issue "network_dns_failure" \
            "DNS resolution failed for $resolved_failures test domains" \
            "Check DNS servers: cat /etc/resolv.conf; Test: nslookup google.com; Restart systemd-resolved: systemctl restart systemd-resolved" \
            "critical"
    fi
    
    # Check DNS response time
    if command_exists dig; then
        local dns_response=$(dig google.com 2>/dev/null | grep -oP 'Query time: \K[0-9]+' | head -1)
        if [[ -n "$dns_response" ]] && [[ "$dns_response" -gt 200 ]]; then
            print_warning "DNS response time high: ${dns_response}ms"
            add_issue "network_slow_dns" \
                "DNS response time is ${dns_response}ms (slow)" \
                "Consider changing DNS servers to faster ones (Cloudflare 1.1.1.1, Google 8.8.8.8)" \
                "warning"
        fi
    fi
}

# Check internet connectivity
check_internet_connectivity() {
    print_info "Testing internet connectivity..."
    
    local test_hosts=("8.8.8.8" "1.1.1.1" "208.67.222.222")
    local reachable_hosts=0
    
    for host in "${test_hosts[@]}"; do
        if ping -c2 -W3 "$host" &>/dev/null; then
            print_success "Internet reachable via $host"
            ((reachable_hosts++))
            break
        fi
    done
    
    if [[ $reachable_hosts -eq 0 ]]; then
        add_issue "network_no_internet" \
            "No internet connectivity - cannot reach any external hosts" \
            "Check: ip route; ping <gateway>; Check firewall rules; Verify ISP connection" \
            "critical"
        return 1
    fi
    
    # Test HTTP/HTTPS connectivity
    if command_exists curl; then
        if curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 https://google.com 2>/dev/null | grep -q "200\|301\|302"; then
            print_success "HTTPS connectivity works"
        else
            print_warning "HTTPS connectivity issues"
            add_issue "network_https_failure" \
                "HTTPS connectivity test failed" \
                "Check firewall rules blocking port 443; Check proxy configuration; Verify SSL/TLS" \
                "warning"
        fi
    fi
}

# Check latency and packet loss
check_latency_and_packet_loss() {
    print_info "Measuring network latency and packet loss..."
    
    local test_hosts=("8.8.8.8" "1.1.1.1")
    local high_latency=0
    local packet_loss=0
    
    for host in "${test_hosts[@]}"; do
        local ping_output=$(ping -c10 "$host" 2>/dev/null)
        
        if [[ -n "$ping_output" ]]; then
            local avg_latency=$(echo "$ping_output" | awk -F'/' '/rtt/ {print $5}')
            local loss_percent=$(echo "$ping_output" | grep -oP '\d+(?=% packet loss)' | head -1)
            
            if [[ -n "$avg_latency" ]]; then
                print_info "$host latency: ${avg_latency}ms"
                
                if (( $(echo "$avg_latency > 150" | bc -l 2>/dev/null || echo "0") )); then
                    print_warning "High latency to $host: ${avg_latency}ms"
                    ((high_latency++))
                fi
            fi
            
            if [[ -n "$loss_percent" ]] && [[ "$loss_percent" -gt 5 ]]; then
                print_warning "Packet loss to $host: ${loss_percent}%"
                ((packet_loss++))
            fi
        fi
    done
    
    if [[ $high_latency -gt 0 ]]; then
        add_issue "network_high_latency" \
            "High latency detected to external hosts" \
            "Run: mtr 8.8.8.8; Check for network congestion, WiFi interference, or ISP issues" \
            "warning"
    fi
    
    if [[ $packet_loss -gt 0 ]]; then
        add_issue "network_packet_loss" \
            "Packet loss detected (${packet_loss}% or higher)" \
            "Run: mtr --report 8.8.8.8; Check cables, switches, and wireless interference" \
            "critical"
    fi
    
    # MTR report for advanced diagnostics
    if command_exists mtr && [[ $packet_loss -gt 0 ]] || [[ $high_latency -gt 0 ]]; then
        print_info "Running MTR trace (this may take a moment)..."
        local mtr_output=$(mtr --report --report-cycles=5 8.8.8.8 2>/dev/null | head -20)
        echo "$mtr_output" >> /var/log/tuxfix_network.log 2>/dev/null
    fi
}

# Check bandwidth utilization
check_bandwidth_utilization() {
    print_info "Checking bandwidth utilization..."
    
    local interfaces=$(ip link show | grep -E '^[0-9]+:' | grep -v lo | awk -F': ' '{print $2}')
    
    for iface in $interfaces; do
        # Get current and previous RX/TX bytes
        local rx_bytes=$(cat /sys/class/net/"$iface"/statistics/rx_bytes 2>/dev/null)
        local tx_bytes=$(cat /sys/class/net/"$iface"/statistics/tx_bytes 2>/dev/null)
        
        if [[ -n "$rx_bytes" ]] && [[ -n "$tx_bytes" ]]; then
            local rx_mb=$((rx_bytes / 1024 / 1024))
            local tx_mb=$((tx_bytes / 1024 / 1024))
            
            print_info "$iface: RX=${rx_mb}MB, TX=${tx_mb}MB since boot"
            
            # Alert on high bandwidth usage
            if [[ $rx_mb -gt 10000 ]] || [[ $tx_mb -gt 10000 ]]; then
                add_issue "network_high_bandwidth_$iface" \
                    "Interface $iface has high bandwidth usage: RX=${rx_mb}MB, TX=${tx_mb}MB" \
                    "Run: nethogs; iptraf-ng; Check for unusual traffic patterns" \
                    "warning"
            fi
        fi
    done
    
    # Check for network congestion using ss
    if command_exists ss; then
        local tcp_connections=$(ss -t state established | wc -l)
        local tcp_timewait=$(ss -t state time-wait | wc -l)
        
        print_info "TCP connections: $tcp_connections established, $tcp_timewait in time-wait"
        
        if [[ $tcp_connections -gt 1000 ]]; then
            add_issue "network_high_connections" \
                "High number of TCP connections: $tcp_connections" \
                "Check for DDoS, connection leaks, or overloaded services: ss -tan | grep ESTAB | wc -l" \
                "warning"
        fi
    fi
}

# Check TCP ports
check_tcp_ports() {
    print_info "Checking critical TCP ports..."
    
    local critical_ports=("22:SSH" "80:HTTP" "443:HTTPS" "53:DNS" "25:SMTP" "3306:MySQL" "5432:PostgreSQL" "6379:Redis" "27017:MongoDB")
    
    for port_info in "${critical_ports[@]}"; do
        local port="${port_info%:*}"
        local service="${port_info#*:}"
        
        if ss -tln 2>/dev/null | grep -q ":$port "; then
            print_success "Port $port ($service) is listening"
        else
            # Only warn if the service is actually installed
            if command_exists "systemctl" && systemctl list-unit-files | grep -qi "$service"; then
                print_warning "Port $port ($service) is not listening but service may be installed"
                add_issue "network_port_closed_$port" \
                    "Port $port ($service) is not listening" \
                    "Check service status: systemctl status $(echo $service | tr '[:upper:]' '[:lower:]'); Start service if needed" \
                    "warning"
            fi
        fi
    done
    
    # Check for unexpected open ports
    local unexpected_ports=$(ss -tln 2>/dev/null | awk 'NR>1 {print $4}' | grep -oP ':\K\d+' | sort -u)
    local dangerous_ports=("23:Telnet" "21:FTP" "513:rlogin" "514:rsh" "111:portmap")
    
    for port_info in "${dangerous_ports[@]}"; do
        local port="${port_info%:*}"
        local service="${port_info#*:}"
        
        if ss -tln 2>/dev/null | grep -q ":$port "; then
            print_warning "Insecure port $port ($service) is open"
            add_issue "network_insecure_port_$port" \
                "Insecure service ($service) is running on port $port" \
                "Disable service: systemctl disable --now $(echo $service | tr '[:upper:]' '[:lower:]'); Configure firewall to block port" \
                "critical"
        fi
    done
}

# Check firewall rules
check_firewall_rules() {
    print_info "Checking firewall configuration..."
    
    local firewall_active=0
    
    # Check iptables
    if command_exists iptables; then
        local iptables_rules=$(iptables -L -n 2>/dev/null | grep -c "ACCEPT\|DROP\|REJECT")
        
        if [[ $iptables_rules -gt 5 ]]; then
            print_success "iptables has $iptables_rules rules configured"
            firewall_active=1
        else
            print_warning "iptables has minimal rules ($iptables_rules)"
        fi
    fi
    
    # Check firewalld
    if command_exists firewall-cmd && systemctl is-active --quiet firewalld 2>/dev/null; then
        local default_zone=$(firewall-cmd --get-default-zone 2>/dev/null)
        print_success "firewalld active (default zone: $default_zone)"
        firewall_active=1
        
        # Check for public zone with services
        local open_services=$(firewall-cmd --list-services 2>/dev/null)
        print_info "Firewall open services: $open_services"
    fi
    
    # Check ufw (Ubuntu)
    if command_exists ufw && ufw status 2>/dev/null | grep -q "Status: active"; then
        print_success "UFW firewall is active"
        firewall_active=1
    fi
    
    if [[ $firewall_active -eq 0 ]]; then
        add_issue "network_no_firewall" \
            "No active firewall detected" \
            "Enable firewall: ufw enable (Ubuntu); systemctl enable --now firewalld (RHEL/Fedora); Or configure iptables" \
            "critical"
    fi
    
    # Check for common blocking issues
    if command_exists iptables; then
        if iptables -L INPUT -n 2>/dev/null | grep -q "DROP.*0.0.0.0/0"; then
            print_warning "Default DROP policy on INPUT chain - may block legitimate traffic"
            add_issue "network_firewall_default_drop" \
                "Firewall has default DROP policy on INPUT chain" \
                "Ensure required services are explicitly allowed: iptables -A INPUT -p tcp --dport 22 -j ACCEPT" \
                "warning"
        fi
    fi
}

# Check routing table
check_routing_table() {
    print_info "Checking routing table..."
    
    local routes=$(ip route show 2>/dev/null)
    
    if [[ -z "$routes" ]]; then
        add_issue "network_no_routes" \
            "No routes in routing table" \
            "Add default route: ip route add default via <gateway>" \
            "critical"
        return 1
    fi
    
    # Check for duplicate routes
    local duplicate_routes=$(ip route show 2>/dev/null | sort | uniq -d)
    if [[ -n "$duplicate_routes" ]]; then
        print_warning "Duplicate routes detected"
        add_issue "network_duplicate_routes" \
            "Duplicate routes in routing table" \
            "Remove duplicate: ip route del <duplicate_route>; Check DHCP and static configurations" \
            "warning"
    fi
    
    # Check for correct interface associations
    local routes_without_interface=$(ip route show 2>/dev/null | grep -v "dev" | wc -l)
    if [[ $routes_without_interface -gt 0 ]]; then
        print_warning "Routes without interface specification found"
        add_issue "network_routes_no_interface" \
            "$routes_without_interface routes missing interface specification" \
            "Review routing table: ip route show; Add 'dev <interface>' to routes" \
            "warning"
    fi
}

# Check MTU issues
check_mtu_issues() {
    print_info "Checking MTU configuration..."
    
    local interfaces=$(ip link show | grep -E '^[0-9]+:' | grep -v lo | awk -F': ' '{print $2}')
    
    for iface in $interfaces; do
        local current_mtu=$(ip link show "$iface" 2>/dev/null | grep -oP 'mtu \K[0-9]+')
        
        print_info "$iface MTU: $current_mtu"
        
        # Standard MTU should be 1500 for Ethernet
        if [[ "$current_mtu" -lt 1400 ]] && [[ "$current_mtu" -gt 0 ]]; then
            print_warning "Interface $iface has non-standard MTU: $current_mtu"
            add_issue "network_nonstandard_mtu_$iface" \
                "Interface $iface MTU is $current_mtu (standard is 1500)" \
                "Reset MTU: ip link set dev $iface mtu 1500; Check VPN/tunnel configurations" \
                "warning"
        fi
        
        # Test MTU to gateway
        local gateway=$(ip route show default 2>/dev/null | awk '/default/ {print $3}' | head -1)
        if [[ -n "$gateway" ]]; then
            if ! ping -M do -c1 -s 1472 "$gateway" &>/dev/null; then
                print_warning "MTU path issue to gateway $gateway"
                add_issue "network_mtu_path_issue_$iface" \
                    "MTU path discovery issue - packets may be getting fragmented" \
                    "Test: ping -M do -s 1472 $gateway; Reduce MTU gradually until it works" \
                    "warning"
            fi
        fi
    done
}

# Check ARP table
check_arp_table() {
    print_info "Checking ARP table..."
    
    local incomplete_entries=$(ip neigh show 2>/dev/null | grep -c "INCOMPLETE")
    
    if [[ $incomplete_entries -gt 5 ]]; then
        print_warning "$incomplete_entries incomplete ARP entries found"
        add_issue "network_arp_incomplete" \
            "Found $incomplete_entries incomplete ARP entries" \
            "Check network connectivity to neighboring hosts; Possible ARP spoofing or network issues" \
            "warning"
    fi
    
    # Check for ARP spoofing (multiple IPs with same MAC)
    local duplicate_macs=$(ip neigh show 2>/dev/null | awk '{print $5}' | sort | uniq -d)
    if [[ -n "$duplicate_macs" ]]; then
        print_warning "Possible ARP spoofing: Duplicate MAC addresses found"
        add_issue "network_arp_spoofing" \
            "Possible ARP spoofing detected - multiple IPs share same MAC" \
            "Investigate: arp -a; Check for network misconfiguration or security incident" \
            "critical"
    fi
}

# Check network services
check_network_services() {
    print_info "Checking network services..."
    
    if command_exists systemctl; then
        local network_services=("NetworkManager" "systemd-networkd" "networking" "network")
        
        for service in "${network_services[@]}"; do
            if systemctl list-unit-files | grep -qi "$service"; then
                if systemctl is-active --quiet "$service" 2>/dev/null; then
                    print_success "$service is active"
                elif systemctl is-enabled --quiet "$service" 2>/dev/null; then
                    print_warning "$service is enabled but not active"
                    add_issue "network_service_inactive_$service" \
                        "$service is enabled but not running" \
                        "Start: systemctl start $service; Check logs: journalctl -u $service -n 50" \
                        "warning"
                fi
            fi
        done
    fi
    
    # Check DHCP client
    if pgrep -f "dhclient|dhcpcd" > /dev/null; then
        print_success "DHCP client is running"
    else
        print_info "No DHCP client detected - assuming static configuration"
    fi
}

# Check bonding/teaming
check_bonding_teaming() {
    print_info "Checking network bonding/teaming..."
    
    if [[ -d /proc/net/bonding ]]; then
        print_info "Network bonding detected"
        
        for bond in /proc/net/bonding/*; do
            local bond_name=$(basename "$bond")
            local bond_mode=$(grep "Bonding Mode:" "$bond" 2>/dev/null | awk -F: '{print $2}' | xargs)
            local bond_status=$(grep "MII Status:" "$bond" 2>/dev/null | awk -F: '{print $2}' | xargs)
            
            print_info "Bond $bond_name: mode=$bond_mode, status=$bond_status"
            
            # Check for degraded bond
            local active_slaves=$(grep -c "Slave Interface:" "$bond" 2>/dev/null)
            local up_slaves=$(grep -c "MII Status: up" "$bond" 2>/dev/null)
            
            if [[ $active_slaves -gt 0 ]] && [[ $up_slaves -lt $active_slaves ]]; then
                print_warning "Bond $bond_name is degraded ($up_slaves/$active_slaves interfaces up)"
                add_issue "network_bond_degraded_$bond_name" \
                    "Network bond $bond_name is degraded ($up_slaves/$active_slaves interfaces up)" \
                    "Check physical interfaces: cat /proc/net/bonding/$bond_name; Replace failed NICs or cables" \
                    "critical"
            fi
        done
    fi
}

# Check VLAN configuration
check_vlan_configuration() {
    print_info "Checking VLAN configuration..."
    
    local vlan_interfaces=$(ip link show | grep -E '@|\.' | grep -v lo | awk -F': ' '{print $2}')
    
    if [[ -n "$vlan_interfaces" ]]; then
        print_info "VLAN interfaces detected: $vlan_interfaces"
        
        for vlan in $vlan_interfaces; do
            local parent_iface=$(echo "$vlan" | grep -oP '(?<=@).+' | head -1)
            local vlan_id=$(echo "$vlan" | grep -oP '\d+' | head -1)
            
            if [[ -n "$parent_iface" ]] && [[ -n "$vlan_id" ]]; then
                print_info "VLAN $vlan_id on $parent_iface"
                
                # Check if parent interface is up
                if ip link show "$parent_iface" 2>/dev/null | grep -q "state UP"; then
                    print_success "Parent interface $parent_iface is up"
                else
                    print_warning "Parent interface $parent_iface for VLAN $vlan is down"
                    add_issue "network_vlan_parent_down_$vlan" \
                        "Parent interface $parent_iface for VLAN $vlan is down" \
                        "Bring up parent interface: ip link set $parent_iface up" \
                        "warning"
                fi
            fi
        done
    fi
}

# Check IPv6 configuration
check_ipv6_configuration() {
    print_info "Checking IPv6 configuration..."
    
    local ipv6_enabled=$(sysctl -n net.ipv6.conf.all.disable_ipv6 2>/dev/null)
    
    if [[ "$ipv6_enabled" == "1" ]]; then
        print_info "IPv6 is disabled system-wide"
        return 0
    fi
    
    # Check for IPv6 addresses
    local ipv6_addresses=$(ip -6 addr show scope global 2>/dev/null | grep -c "inet6")
    
    if [[ $ipv6_addresses -gt 0 ]]; then
        print_success "IPv6 is enabled with $ipv6_addresses global addresses"
        
        # Test IPv6 connectivity
        if ping6 -c2 -W2 2001:4860:4860::8888 &>/dev/null; then
            print_success "IPv6 internet connectivity works"
        else
            print_warning "IPv6 connectivity test failed"
            add_issue "network_ipv6_connectivity" \
                "IPv6 enabled but cannot reach external IPv6 hosts" \
                "Check IPv6 routing: ip -6 route show; Check IPv6 DNS: cat /etc/resolv.conf; Verify ISP IPv6 support" \
                "warning"
        fi
    else
        print_info "IPv6 enabled but no global addresses assigned"
    fi
}

# Check network security
check_network_security() {
    print_info "Checking network security..."
    
    # Check for suspicious listening ports
    local listening_ports=$(ss -tln 2>/dev/null | awk 'NR>1 {print $4}' | grep -oP ':\K\d+' | sort -u)
    
    for port in $listening_ports; do
        # Alert on high-numbered ports without known services
        if [[ $port -gt 10000 ]] && [[ $port -lt 65535 ]]; then
            local process=$(ss -tlnp 2>/dev/null | grep ":$port " | grep -oP 'users:\(\("([^"]+)"' | head -1 | sed 's/users:(("//' | sed 's/"//')
            
            if [[ -n "$process" ]]; then
                print_info "High port $port listening (process: $process)"
                
                # Check if it's a known service
                if ! echo "$process" | grep -qi "docker\|containerd\|kube\|java\|node\|python"; then
                    add_issue "network_suspicious_port_$port" \
                        "Suspicious high port $port listening (process: $process)" \
                        "Investigate: netstat -tlnp | grep :$port; Check if this service is expected" \
                        "warning"
                fi
            fi
        fi
    done
    
    # Check for IP forwarding (routing enabled)
    local ip_forward=$(sysctl -n net.ipv4.ip_forward 2>/dev/null)
    
    if [[ "$ip_forward" == "1" ]]; then
        print_warning "IP forwarding is enabled (system acts as router)"
        add_issue "network_ip_forwarding" \
            "IP forwarding is enabled - system can route traffic between networks" \
            "If not intended as router, disable: sysctl -w net.ipv4.ip_forward=0; Add net.ipv4.ip_forward=0 to /etc/sysctl.conf" \
            "warning"
    fi
    
    # Check for promiscuous mode
    local promisc_ifaces=$(ip link show 2>/dev/null | grep -B1 "PROMISC" | grep -E '^[0-9]+:' | awk -F': ' '{print $2}')
    
    if [[ -n "$promisc_ifaces" ]]; then
        print_warning "Promiscuous mode enabled on: $promisc_ifaces"
        add_issue "network_promiscuous_mode" \
            "Network interfaces in promiscuous mode: $promisc_ifaces" \
            "Investigate if packet sniffing is intentional; Disable: ip link set <interface> promisc off" \
            "warning"
    fi
}

# Module metadata
MODULE_NAME="network"
MODULE_DESC="Enterprise network diagnostics: connectivity, DNS, latency, firewall, security, and performance"
