#!/bin/bash

# Module: Services Health Check
# Author: TuxFix Team
# Description: Checks systemd services, crash loops, and failed services

run_services() {
    print_info "Starting services diagnostics..."
    
    # Check if systemd is available
    if ! command -v systemctl &>/dev/null; then
        print_warning "systemctl not found - skipping service checks"
        return 1
    fi
    
    # Check system state
    local system_state=$(systemctl is-system-running 2>/dev/null || echo "unknown")
    print_info "System state: $system_state"
    
    if [[ "$system_state" == "degraded" ]] || [[ "$system_state" == "maintenance" ]]; then
        add_issue "system_state" \
            "System is in degraded/maintenance state" \
            "Check: systemctl --failed; journalctl -p 3 -xb" \
            "critical"
    fi
    
    # Check for failed services
    local failed_services=$(systemctl --failed --no-legend 2>/dev/null | awk '{print $1}')
    
    if [[ -n "$failed_services" ]]; then
        print_warning "Failed services detected:"
        local service_list=""
        while IFS= read -r service; do
            [[ -z "$service" ]] && continue
            print_item "$service"
            service_list="$service_list $service"
            
            # Get service status for more details
            local status=$(systemctl status "$service" --no-pager -l 2>/dev/null | head -5)
        done <<< "$failed_services"
        
        add_issue "failed_services" \
            "Failed services detected: $service_list" \
            "Check: systemctl status <service>; journalctl -u <service> -xe" \
            "critical"
    else
        print_success "All services are running"
    fi
    
    # Check for crash loops (services restarting too often)
    local crash_services=""
    local services=$(systemctl list-units --type=service --all --no-legend 2>/dev/null | awk '{print $1}')
    
    for service in $services; do
        local restarts=$(systemctl show "$service" -p NRestarts --value 2>/dev/null || echo "0")
        if [[ "$restarts" -ge 3 ]]; then
            crash_services="$crash_services $service($restarts)"
            print_warning "Service $service has restarted $restarts times"
        fi
    done
    
    if [[ -n "$crash_services" ]]; then
        add_issue "service_crashloops" \
            "Service crash loops detected: $crash_services" \
            "Check: journalctl -u <service> -n 100; may need configuration fix or dependency check" \
            "critical"
    fi
    
    # Check essential services
    local essential_services=("sshd" "cron" "rsyslog" "dbus" "systemd-journald")
    local missing_essential=""
    
    for service in "${essential_services[@]}"; do
        if systemctl list-unit-files "${service}.service" &>/dev/null; then
            if ! systemctl is-active --quiet "${service}.service" 2>/dev/null; then
                missing_essential="$missing_essential $service"
                print_warning "Essential service not running: $service"
            fi
        fi
    done
    
    if [[ -n "$missing_essential" ]]; then
        add_issue "essential_services" \
            "Essential services not running: $missing_essential" \
            "Start: systemctl start <service>; systemctl enable <service>" \
            "critical"
    fi
    
    # Check for masked services (might be intentional but worth noting)
    local masked_services=$(systemctl list-unit-files 2>/dev/null | awk '$2=="masked"{print $1}')
    if [[ -n "$masked_services" ]]; then
        add_issue "masked_services" \
            "Masked services found: $(echo $masked_services | tr '\n' ' ')" \
            "If not needed, ignore; to restore: systemctl unmask <service>" \
            "warning"
    fi
    
    # Check systemd timer failures
    local failed_timers=$(systemctl list-units --type=timer --state=failed --no-legend 2>/dev/null | awk '{print $1}')
    if [[ -n "$failed_timers" ]]; then
        add_issue "failed_timers" \
            "Failed timer units: $(echo $failed_timers | tr '\n' ' ')" \
            "Check: systemctl status <timer>; journalctl -u <timer>" \
            "warning"
    fi
    
    return 0
}

MODULE_NAME="services"
MODULE_DESC="Checks system service health, failures, and crash loops"