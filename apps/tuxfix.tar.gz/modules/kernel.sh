#!/bin/bash

# Module: Kernel Health Check
# Author: TuxFix Team
# Description: Checks kernel panics, oops, tainted kernels, and hardware issues

run_kernel() {
    print_info "Starting kernel diagnostics..."
    
    # Check kernel version
    local kernel_version=$(uname -r)
    print_info "Kernel version: $kernel_version"
    
    # Check for tainted kernel
    if [[ -f /proc/sys/kernel/tainted ]]; then
        local tainted=$(cat /proc/sys/kernel/tainted)
        if [[ "$tainted" != "0" ]]; then
            add_issue "kernel_tainted" \
                "Kernel is tainted (value: $tainted) - possibly due to proprietary modules or forced loading" \
                "Check cause: cat /proc/sys/kernel/tainted; lsmod | grep -E ' \(OE\)'" \
                "warning"
        else
            print_success "Kernel is clean (not tainted)"
        fi
    fi
    
    # Check for kernel panics in logs
    local panic_detected=0
    if command -v journalctl &>/dev/null; then
        if journalctl -k -p 0..2 | grep -qi "kernel panic\|oops\|bug:"; then
            panic_detected=1
        fi
    else
        if dmesg | grep -qi "kernel panic\|oops\|bug:"; then
            panic_detected=1
        fi
    fi
    
    if [[ $panic_detected -eq 1 ]]; then
        add_issue "kernel_panic" \
            "Kernel panic or OOPS detected in logs" \
            "Check: dmesg | grep -i 'panic\|oops'; consider updating kernel or checking hardware" \
            "critical"
    else
        print_success "No kernel panics detected"
    fi
    
    # Check for hardware errors
    if command -v mcelog &>/dev/null; then
        if mcelog --client 2>/dev/null | grep -q .; then
            add_issue "hardware_mce" \
                "Machine Check Exception (MCE) errors detected - possible hardware issues" \
                "Run: mcelog --ascii; check CPU/RAM health" \
                "critical"
        fi
    fi
    
    # Check for failed kernel modules
    local failed_modules=$(dmesg | grep -i "failed to load" | awk '{print $NF}' | sort -u)
    if [[ -n "$failed_modules" ]]; then
        add_issue "kernel_modules" \
            "Failed to load kernel modules: $(echo $failed_modules | tr '\n' ' ')" \
            "Check: modprobe <module_name>; may need to reinstall drivers" \
            "warning"
    fi
    
    # Check for segmentation faults
    if dmesg | grep -qi "segfault"; then
        local segfault_count=$(dmesg | grep -c "segfault")
        add_issue "kernel_segfault" \
            "Detected $segfault_count segfault events" \
            "Check application logs; possible memory issues or application bugs" \
            "warning"
    fi
    
    # Check system uptime for recent crashes
    local uptime_seconds=$(awk '{print int($1)}' /proc/uptime)
    if [[ $uptime_seconds -lt 300 ]]; then
        add_issue "recent_reboot" \
            "System rebooted recently (uptime < 5 minutes) - possible crash issues" \
            "Check: journalctl -b -1 | grep -i 'panic\|oops\|error'" \
            "critical"
    fi
    
    return 0
}

# Module info for discovery
MODULE_NAME="kernel"
MODULE_DESC="Checks kernel health, crashes, and hardware issues"