#!/bin/bash

# Module: Example Custom Module
# Author: User
# Description: This is an example module showing how to create custom checks

run_example() {
    print_info "Running example custom checks..."
    
    # Example 1: Check disk space
    local disk_usage=$(df -h / | awk 'NR==2 {print $5}' | sed 's/%//')
    if [[ $disk_usage -gt 90 ]]; then
        add_issue "example_disk_full" \
            "Root partition usage is high: ${disk_usage}%" \
            "Clean logs: journalctl --vacuum-size=100M; remove old files" \
            "critical"
    elif [[ $disk_usage -gt 75 ]]; then
        add_issue "example_disk_warning" \
            "Root partition usage: ${disk_usage}% (exceeds 75%)" \
            "Monitor disk space; consider cleanup or expansion" \
            "warning"
    else
        print_success "Disk space OK (usage: ${disk_usage}%)"
    fi
    
    # Example 2: Check memory
    local mem_total=$(free -m | awk '/^Mem:/ {print $2}')
    local mem_used=$(free -m | awk '/^Mem:/ {print $3}')
    local mem_percent=$((mem_used * 100 / mem_total))
    
    if [[ $mem_percent -gt 95 ]]; then
        add_issue "example_memory_critical" \
            "Memory usage critical: ${mem_percent}%" \
            "Check processes: ps aux --sort=-%mem | head -10; possible memory leak" \
            "critical"
    elif [[ $mem_percent -gt 85 ]]; then
        add_issue "example_memory_warning" \
            "Memory usage is high: ${mem_percent}%" \
            "Monitor memory usage; consider adding RAM or optimizing applications" \
            "warning"
    fi
    
    # Example 3: Check for specific process
    if ! pgrep -x "sshd" > /dev/null; then
        add_issue "example_no_sshd" \
            "SSH service is not running" \
            "Start SSH: systemctl start sshd; systemctl enable sshd" \
            "critical"
    fi
    
    # Example 4: Custom check - check for specific file
    if [[ ! -f "/etc/motd" ]]; then
        add_issue "example_motd_missing" \
            "Missing /etc/motd file" \
            "Create: echo 'Welcome' > /etc/motd" \
            "warning"
    fi
    
    return 0
}

# Module metadata
MODULE_NAME="example"
MODULE_DESC="Example module - demonstrates how to create custom checks"