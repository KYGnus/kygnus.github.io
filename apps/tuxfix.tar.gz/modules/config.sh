#!/bin/bash

# Module: Configuration Health Check
# Author: TuxFix Team
# Description: Checks configuration files for syntax errors, security issues

run_config() {
    print_info "Starting configuration diagnostics..."
    
    # ============================================
    # Check critical configuration files
    # ============================================
    
    declare -A CRITICAL_CONFIGS=(
        ["/etc/fstab"]="Filesystem mounting"
        ["/etc/hosts"]="Hostname resolution"
        ["/etc/hostname"]="System hostname"
        ["/etc/resolv.conf"]="DNS configuration"
        ["/etc/sudoers"]="Sudo privileges"
        ["/etc/ssh/sshd_config"]="SSH service configuration"
    )
    
    for config in "${!CRITICAL_CONFIGS[@]}"; do
        if [[ -f "$config" ]]; then
            # Check file permissions
            local perms=$(stat -c %a "$config" 2>/dev/null)
            
            if [[ "$config" == "/etc/sudoers" ]] && [[ "$perms" != "440" ]]; then
                add_issue "config_perms_$(basename $config)" \
                    "$config has incorrect permissions: $perms (should be 440)" \
                    "chmod 440 $config" \
                    "critical"
            elif [[ "$config" == "/etc/shadow" ]] && [[ "$perms" != "600" ]] && [[ "$perms" != "640" ]]; then
                add_issue "config_perms_$(basename $config)" \
                    "$config has insecure permissions: $perms" \
                    "chmod 640 $config" \
                    "critical"
            fi
            
            # Validate syntax based on file type
            case "$config" in
                */sudoers)
                    if command -v visudo &>/dev/null; then
                        if ! visudo -c -f "$config" &>/dev/null; then
                            add_issue "config_syntax_$(basename $config)" \
                                "$config has syntax errors" \
                                "Run: visudo -c -f $config; fix syntax errors" \
                                "critical"
                        fi
                    fi
                    ;;
                */sshd_config)
                    if command -v sshd &>/dev/null; then
                        if ! sshd -t -f "$config" &>/dev/null; then
                            add_issue "config_syntax_$(basename $config)" \
                                "$config has syntax errors" \
                                "Run: sshd -t -f $config; fix configuration" \
                                "critical"
                        fi
                    fi
                    ;;
            esac
            
            print_success "$config: exists with correct permissions"
        else
            add_issue "config_missing_$(basename $config)" \
                "Missing critical config: $config (${CRITICAL_CONFIGS[$config]})" \
                "Restore from backup or regenerate default configuration" \
                "critical"
        fi
    done
    
    # ============================================
    # SSH Security Configuration
    # ============================================
    
    if [[ -f /etc/ssh/sshd_config ]]; then
        print_info "Checking SSH security configuration..."
        
        # Check for insecure SSH settings
        if grep -q "^PermitRootLogin yes" /etc/ssh/sshd_config 2>/dev/null; then
            add_issue "ssh_root_login" \
                "SSH allows root login directly (insecure)" \
                "Edit /etc/ssh/sshd_config: PermitRootLogin no; systemctl restart sshd" \
                "critical"
        fi
        
        if grep -q "^PasswordAuthentication yes" /etc/ssh/sshd_config 2>/dev/null; then
            add_issue "ssh_password_auth" \
                "SSH allows password authentication (key-based recommended)" \
                "Set: PasswordAuthentication no; ensure key authentication is configured" \
                "warning"
        fi
        
        if ! grep -q "^Protocol 2" /etc/ssh/sshd_config 2>/dev/null; then
            add_issue "ssh_protocol" \
                "SSH protocol not explicitly set to version 2" \
                "Add: Protocol 2 to /etc/ssh/sshd_config" \
                "critical"
        fi
    fi
    
    # ============================================
    # Network Configuration
    # ============================================
    
    # Check DNS configuration
    if [[ -f /etc/resolv.conf ]]; then
        if ! grep -q "^nameserver" /etc/resolv.conf 2>/dev/null; then
            add_issue "dns_missing" \
                "No DNS nameservers configured" \
                "Add: nameserver 8.8.8.8 to /etc/resolv.conf" \
                "critical"
        else
            print_success "DNS configured: $(grep "^nameserver" /etc/resolv.conf | head -1)"
        fi
    fi
    
    # Check hosts file
    if [[ -f /etc/hosts ]]; then
        if ! grep -q "127.0.0.1.*localhost" /etc/hosts 2>/dev/null; then
            add_issue "hosts_localhost" \
                "Missing localhost entry in /etc/hosts" \
                "Add: 127.0.0.1 localhost localhost.localdomain" \
                "warning"
        fi
    fi
    
    # ============================================
    # Performance Configuration
    # ============================================
    
    # Check sysctl performance settings
    if [[ -f /etc/sysctl.conf ]]; then
        print_info "Checking performance tuning parameters..."
        
        # Check swappiness
        local swappiness=$(sysctl -n vm.swappiness 2>/dev/null)
        if [[ -n "$swappiness" ]] && [[ "$swappiness" -gt 60 ]]; then
            add_issue "sysctl_swappiness" \
                "vm.swappiness = $swappiness (too high, may cause excessive swap usage)" \
                "Set: vm.swappiness=10 in /etc/sysctl.conf; sysctl -p" \
                "warning"
        fi
        
        # Check file limits
        if ! grep -q "nofile" /etc/security/limits.conf 2>/dev/null; then
            add_issue "limits_nofile" \
                "File descriptor limits not configured" \
                "Add: * soft nofile 65535; * hard nofile 65535 to /etc/security/limits.conf" \
                "warning"
        fi
    fi
    
    # ============================================
    # Service Configuration Files
    # ============================================
    
    # Check systemd service files for syntax errors
    if command -v systemd-analyze &>/dev/null; then
        print_info "Checking systemd service file syntax..."
        
        local bad_services=""
        for service_file in /etc/systemd/system/*.service; do
            if [[ -f "$service_file" ]]; then
                if ! systemd-analyze verify "$service_file" &>/dev/null 2>&1; then
                    bad_services="$bad_services $(basename $service_file)"
                fi
            fi
        done
        
        if [[ -n "$bad_services" ]]; then
            add_issue "systemd_syntax_errors" \
                "Service files with syntax errors: $bad_services" \
                "Run: systemd-analyze verify <service>; fix syntax errors" \
                "warning"
        fi
    fi
    
    # ============================================
    # Application Configurations
    # ============================================
    
    # Check Nginx configuration if installed
    if command -v nginx &>/dev/null; then
        if ! nginx -t &>/dev/null 2>&1; then
            add_issue "nginx_config" \
                "Nginx configuration has syntax errors" \
                "Run: nginx -t; check and fix configuration files" \
                "critical"
        else
            print_success "Nginx configuration validated"
        fi
    fi
    
    # Check Apache configuration if installed
    if command -v apache2ctl &>/dev/null; then
        if ! apache2ctl configtest &>/dev/null 2>&1; then
            add_issue "apache_config" \
                "Apache configuration has syntax errors" \
                "Run: apache2ctl configtest; check configuration files" \
                "critical"
        else
            print_success "Apache configuration validated"
        fi
    fi
    
    return 0
}

MODULE_NAME="config"
MODULE_DESC="Checks configuration file syntax, permissions, and security settings"