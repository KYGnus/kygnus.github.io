#!/bin/bash

# TuxFix - Linux System Diagnostic and Repair Tool
# Modular Architecture - Automatically discovers and runs modules

set -euo pipefail

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODULES_DIR="${SCRIPT_DIR}/modules"

# Color codes for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'
BOLD='\033[1m'

# Global arrays to store issues
declare -A ISSUES
declare -A ISSUE_FIXES
declare -A ISSUE_TYPES

# Global variables
AUTO_FIX=0
VERBOSE=0
DISTRO=""
PKG_MANAGER=""
SELECTED_MODULES=()
LIST_MODULES_ONLY=0

# ============================================
# UI Functions
# ============================================

print_header() {
    echo -e "\n${BOLD}${CYAN}========================================${NC}"
    echo -e "${BOLD}${CYAN}   $1${NC}"
    echo -e "${BOLD}${CYAN}========================================${NC}"
}

print_section() {
    echo -e "\n${BOLD}${BLUE}▶ $1${NC}"
    echo -e "${BLUE}────────────────────────────────────────${NC}"
}

print_success() {
    echo -e "  ${GREEN}✓${NC} ${GREEN}$1${NC}"
}

print_warning() {
    echo -e "  ${YELLOW}⚠${NC} ${YELLOW}$1${NC}"
}

print_error() {
    echo -e "  ${RED}✗${NC} ${RED}$1${NC}"
}

print_info() {
    echo -e "  ${BLUE}ℹ${NC} ${CYAN}$1${NC}"
}

print_item() {
    echo -e "    • $1"
}

# ============================================
# Core Functions
# ============================================

# Add issue to tracking
add_issue() {
    local key="$1"
    local description="$2"
    local fix="${3:-}"
    local type="${4:-warning}"
    
    ISSUES["$key"]="$description"
    ISSUE_FIXES["$key"]="$fix"
    ISSUE_TYPES["$key"]="$type"
}

# Detect Linux distribution
detect_distro() {
    if [[ -f /etc/os-release ]]; then
        . /etc/os-release
        DISTRO="$ID"
        
        case "$ID" in
            ubuntu|debian)
                PKG_MANAGER="apt"
                ;;
            fedora|rhel|centos)
                PKG_MANAGER="dnf"
                ;;
            suse|opensuse)
                PKG_MANAGER="zypper"
                ;;
            arch|manjaro)
                PKG_MANAGER="pacman"
                ;;
            *)
                PKG_MANAGER="unknown"
                ;;
        esac
    else
        DISTRO="unknown"
        PKG_MANAGER="unknown"
    fi
    
    print_info "Detected: $DISTRO (Package manager: $PKG_MANAGER)"
}

# ============================================
# Module Management
# ============================================

# List all available modules
list_modules() {
    print_header "Available Modules"
    
    if [[ ! -d "$MODULES_DIR" ]]; then
        print_error "Modules directory not found: $MODULES_DIR"
        return 1
    fi
    
    local modules_found=0
    
    for module in "$MODULES_DIR"/*.sh; do
        if [[ -f "$module" ]]; then
            local module_name=$(basename "$module" .sh)
            modules_found=1
            
            # Try to get module description
            local description=$(grep -m1 "^# Description:" "$module" 2>/dev/null | cut -d: -f2- | xargs)
            if [[ -z "$description" ]]; then
                description=$(grep -m1 "^# Module:" "$module" 2>/dev/null | cut -d: -f2- | xargs)
            fi
            if [[ -z "$description" ]]; then
                description="No description available"
            fi
            
            # Check if module has required function
            if grep -q "run_${module_name}" "$module" 2>/dev/null; then
                echo -e "  ${GREEN}✓${NC} ${BOLD}$module_name${NC} - $description"
            else
                echo -e "  ${YELLOW}⚠${NC} ${BOLD}$module_name${NC} - $description ${YELLOW}(missing run_${module_name} function)${NC}"
            fi
        fi
    done
    
    if [[ $modules_found -eq 0 ]]; then
        print_error "No modules found in $MODULES_DIR"
        echo -e "\n${YELLOW}To create a module:${NC}"
        echo "  1. Create a .sh file in $MODULES_DIR"
        echo "  2. Add function: run_<modulename>() { ... }"
        echo "  3. Make it executable: chmod +x $MODULES_DIR/yourmodule.sh"
    else
        echo -e "\n${BLUE}Usage:${NC}"
        echo "  sudo tuxfix                     # Run all modules"
        echo "  sudo tuxfix --module kernel     # Run specific module"
        echo "  sudo tuxfix --module kernel,services  # Run multiple modules"
    fi
}

# Discover and run all modules
run_modules() {
    if [[ ! -d "$MODULES_DIR" ]]; then
        print_error "Modules directory not found: $MODULES_DIR"
        exit 1
    fi
    
    # Find all .sh files in modules directory
    local all_modules=()
    while IFS= read -r module; do
        all_modules+=("$module")
    done < <(find "$MODULES_DIR" -maxdepth 1 -name "*.sh" -type f | sort)
    
    if [[ ${#all_modules[@]} -eq 0 ]]; then
        print_error "No modules found in $MODULES_DIR"
        exit 1
    fi
    
    # Filter modules if specific ones were selected
    local modules_to_run=()
    
    if [[ ${#SELECTED_MODULES[@]} -gt 0 ]]; then
        # Run only selected modules
        for selected in "${SELECTED_MODULES[@]}"; do
            local found=0
            for module in "${all_modules[@]}"; do
                local module_name=$(basename "$module" .sh)
                if [[ "$module_name" == "$selected" ]]; then
                    modules_to_run+=("$module")
                    found=1
                    break
                fi
            done
            if [[ $found -eq 0 ]]; then
                print_warning "Module '$selected' not found"
            fi
        done
        
        if [[ ${#modules_to_run[@]} -eq 0 ]]; then
            print_error "No valid modules selected"
            exit 1
        fi
        
        print_info "Running selected modules: ${#modules_to_run[@]}"
        for module in "${modules_to_run[@]}"; do
            local module_name=$(basename "$module" .sh)
            print_item "$module_name"
        done
    else
        # Run all modules
        modules_to_run=("${all_modules[@]}")
        print_info "Found ${#modules_to_run[@]} module(s):"
        for module in "${modules_to_run[@]}"; do
            local module_name=$(basename "$module" .sh)
            print_item "$module_name"
        done
    fi
    
    # Run each module
    local module_count=0
    local failed_modules=0
    
    for module in "${modules_to_run[@]}"; do
        ((module_count++))
        local module_name=$(basename "$module" .sh)
        
        print_section "Running Module: $module_name ($module_count/${#modules_to_run[@]})"
        
        # Source and run the module
        if source "$module"; then
            # Check if module has main function named after itself
            if declare -f "run_${module_name}" > /dev/null 2>&1; then
                if "run_${module_name}"; then
                    print_success "Module $module_name completed successfully"
                else
                    print_warning "Module $module_name completed with issues"
                    ((failed_modules++))
                fi
            # Fallback to generic run_module function
            elif declare -f "run_module" > /dev/null 2>&1; then
                if run_module; then
                    print_success "Module $module_name completed successfully"
                else
                    print_warning "Module $module_name completed with issues"
                    ((failed_modules++))
                fi
            else
                print_error "Module $module_name has no run_${module_name}() function"
                ((failed_modules++))
            fi
        else
            print_error "Failed to load module: $module_name"
            ((failed_modules++))
        fi
    done
    
    if [[ $failed_modules -gt 0 ]]; then
        print_warning "$failed_modules module(s) had issues"
    fi
}

# ============================================
# Results and Repair
# ============================================

# Display all issues found
display_issues() {
    if [[ ${#ISSUES[@]} -eq 0 ]]; then
        print_success "\n🎉 No issues found! System looks healthy."
        return 0
    fi
    
    echo -e "\n${BOLD}${YELLOW}════════════════════════════════════════════${NC}"
    echo -e "${BOLD}${YELLOW}   ISSUES FOUND (${#ISSUES[@]})${NC}"
    echo -e "${BOLD}${YELLOW}════════════════════════════════════════════${NC}\n"
    
    local critical=0
    local warning=0
    
    for key in "${!ISSUES[@]}"; do
        local type="${ISSUE_TYPES[$key]}"
        local desc="${ISSUES[$key]}"
        
        if [[ "$type" == "critical" ]]; then
            echo -e "  ${RED}🔴 CRITICAL:${NC} $desc"
            ((critical++))
        else
            echo -e "  ${YELLOW}🟡 WARNING:${NC} $desc"
            ((warning++))
        fi
        
        if [[ -n "${ISSUE_FIXES[$key]}" ]] && [[ "$VERBOSE" == "1" ]]; then
            echo -e "      ${BLUE}→ Fix:${NC} ${ISSUE_FIXES[$key]}"
        fi
        echo
    done
    
    echo -e "${BOLD}Summary:${NC} $critical critical, $warning warnings\n"
}

# Interactive repair menu
interactive_repair() {
    if [[ ${#ISSUES[@]} -eq 0 ]]; then
        print_success "No issues to repair!"
        return 0
    fi
    
    echo -e "\n${BOLD}${CYAN}════════════════════════════════════════════${NC}"
    echo -e "${BOLD}${CYAN}   REPAIR MENU${NC}"
    echo -e "${BOLD}${CYAN}════════════════════════════════════════════${NC}\n"
    
    local keys=()
    local index=1
    for key in "${!ISSUES[@]}"; do
        keys+=("$key")
        echo -e "${index}. ${ISSUES[$key]}"
        ((index++))
    done
    
    echo
    echo -e "${BOLD}Options:${NC}"
    echo "  a - Fix all issues"
    echo "  i - Interactive fix (ask for each)"
    echo "  s - Show details only"
    echo "  q - Quit"
    echo
    
    read -p "Choose option [a/i/s/q]: " choice
    
    case $choice in
        a|A)
            echo -e "\n${GREEN}Fixing all issues...${NC}\n"
            for key in "${keys[@]}"; do
                if [[ -n "${ISSUE_FIXES[$key]}" ]]; then
                    echo -e "${YELLOW}Fixing: ${ISSUES[$key]}${NC}"
                    if eval "${ISSUE_FIXES[$key]}" 2>/dev/null; then
                        print_success "Fixed successfully"
                    else
                        print_error "Failed to fix"
                    fi
                    echo
                fi
            done
            ;;
        i|I)
            for key in "${keys[@]}"; do
                echo -e "\n${YELLOW}Issue: ${ISSUES[$key]}${NC}"
                if [[ -n "${ISSUE_FIXES[$key]}" ]]; then
                    echo -e "${BLUE}Fix command: ${ISSUE_FIXES[$key]}${NC}"
                    read -p "Apply this fix? [y/N]: " apply
                    if [[ "$apply" =~ ^[Yy]$ ]]; then
                        if eval "${ISSUE_FIXES[$key]}" 2>/dev/null; then
                            print_success "Fixed"
                        else
                            print_error "Failed to fix"
                        fi
                    else
                        print_info "Skipped"
                    fi
                else
                    print_warning "No automatic fix available"
                fi
            done
            ;;
        s|S)
            echo -e "\n${BLUE}Showing issue details only...${NC}"
            display_issues
            ;;
        q|Q)
            echo -e "\n${BLUE}Exiting without repairs.${NC}"
            exit 0
            ;;
        *)
            echo -e "\n${RED}Invalid option${NC}"
            ;;
    esac
}

# ============================================
# Main
# ============================================

# Parse command line arguments
parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --fix|-f)
                AUTO_FIX=1
                shift
                ;;
            --verbose|-v)
                VERBOSE=1
                shift
                ;;
            --module|-m)
                shift
                if [[ $# -eq 0 ]] || [[ "$1" == --* ]]; then
                    print_error "Module name required for --module option"
                    echo "Usage: $0 --module <module_name>"
                    echo "Example: $0 --module network"
                    echo "Multiple modules: $0 --module kernel,services,config"
                    exit 1
                fi
                # Split comma-separated module names
                IFS=',' read -ra SELECTED_MODULES <<< "$1"
                shift
                ;;
            --list-modules|-l)
                LIST_MODULES_ONLY=1
                shift
                ;;
            --help|-h)
                echo "TuxFix - Linux System Diagnostic and Repair Tool"
                echo ""
                echo "Usage: $0 [OPTIONS]"
                echo ""
                echo "Options:"
                echo "  --fix, -f                 Automatically fix issues"
                echo "  --verbose, -v             Show detailed output"
                echo "  --module, -m <name>       Run specific module(s)"
                echo "                            Examples:"
                echo "                              --module network"
                echo "                              --module kernel,services,config"
                echo "  --list-modules, -l        List all available modules"
                echo "  --help, -h                Show this help"
                echo ""
                echo "Examples:"
                echo "  sudo $0                     # Run all modules"
                echo "  sudo $0 --fix               # Run all modules and auto-fix"
                echo "  sudo $0 --module network    # Run only network module"
                echo "  sudo $0 --module kernel,services  # Run multiple modules"
                echo "  sudo $0 --list-modules      # List available modules"
                exit 0
                ;;
            *)
                echo "Unknown option: $1"
                echo "Run '$0 --help' for usage"
                exit 1
                ;;
        esac
    done
}

# Main execution
main() {
    # Handle list modules option first
    if [[ $LIST_MODULES_ONLY -eq 1 ]]; then
        list_modules
        exit 0
    fi
    
    print_header "TuxFix - Linux System Diagnostic Tool"
    print_info "Started at: $(date)"
    
    if [[ ${#SELECTED_MODULES[@]} -gt 0 ]]; then
        print_info "Running specific modules: ${SELECTED_MODULES[*]}"
    else
        print_info "Running all modules"
    fi
    
    print_info "Fix mode: $([[ $AUTO_FIX -eq 1 ]] && echo "Enabled" || echo "Disabled")"
    
    # Detect distribution
    detect_distro
    
    # Run modules
    run_modules
    
    # Display results
    display_issues
    
    # Offer repairs if issues found
    if [[ ${#ISSUES[@]} -gt 0 ]]; then
        if [[ $AUTO_FIX -eq 1 ]]; then
            echo -e "\n${GREEN}Auto-fix mode enabled${NC}"
            interactive_repair
        else
            echo -e "\n${YELLOW}Run with --fix to enable repair mode${NC}"
            echo -e "${BLUE}Example: sudo $0 --fix${NC}"
            
            if [[ ${#SELECTED_MODULES[@]} -eq 0 ]]; then
                echo -e "${BLUE}Run specific module: sudo $0 --module network${NC}"
            fi
        fi
    fi
    
    print_header "Diagnostic Complete"
    print_info "Completed at: $(date)"
}

# Run as root check
if [[ $EUID -ne 0 ]]; then
    echo -e "${YELLOW}⚠ Warning: Not running as root. Some checks may be limited.${NC}"
    echo -e "${BLUE}Consider: sudo $0${NC}\n"
fi

# Parse arguments and start
parse_args "$@"
main "$@"